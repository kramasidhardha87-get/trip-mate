# Security notes

- Passwords are stored using PHP `password_hash()` and checked with `password_verify()`.
- SQL queries use PDO prepared statements.
- PHP session IDs are regenerated after successful authentication.
- Keep `config/config.php` private and out of GitHub.
- For public deployment, enable HTTPS, configure secure cookie settings, add CSRF protection and rate limiting, and use a least-privilege database account.
