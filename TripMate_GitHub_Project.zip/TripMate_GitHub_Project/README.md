# TripMate – Smart Travel Planner

TripMate is a PHP + MySQL travel-planning mini project. The supplied frontend is based on the uploaded TripMate HTML prototype and is separated into HTML, CSS and JavaScript files.

## Features
- Destination and tourist-place selection across Indian cities
- Day-wise suggested itinerary
- Budget summary (total, daily and per traveller)
- Google Maps search link and print / Save as PDF
- Travel service links (Rapido, Swiggy and hotel search)
- PHP session-based registration, login and logout
- Saves generated trips to MySQL for the logged-in user

## Technology
HTML5, CSS3, JavaScript (Fetch API), PHP 8+, MySQL.

## Requirements
- XAMPP (Apache + PHP + MySQL) or another PHP/MySQL local server
- PHP PDO MySQL extension enabled
- MySQL 5.7+ / MariaDB with JSON support

## Run locally (XAMPP)
1. Extract the ZIP.
2. Copy the `TripMate_GitHub_Project` folder into `C:\xampp\htdocs\`.
3. Start **Apache** and **MySQL** from XAMPP Control Panel.
4. Open phpMyAdmin: `http://localhost/phpmyadmin`.
5. Import `database.sql`.
6. Copy `config/config.example.php` to `config/config.php`.
7. Edit `config/config.php` with your MySQL host, database, username and password. In a standard local XAMPP setup, username is often `root` and password is blank; confirm your own settings.
8. Open `http://localhost/TripMate_GitHub_Project/`.

## Test
1. Create an account using an email and a password of at least 8 characters.
2. Log in.
3. Choose a destination and at least one place.
4. Generate a trip. The itinerary appears immediately and is saved in the database.
5. Check the `users` and `trips` tables in phpMyAdmin.

## Backend API
- `POST api/auth.php` with `{"action":"register","email":"...","password":"..."}` 
- `POST api/auth.php` with `{"action":"login","email":"...","password":"..."}`
- `POST api/auth.php` with `{"action":"logout"}`
- `GET api/auth.php?action=me`
- `POST api/trips.php` (requires login; stores trip details)
- `GET api/trips.php` (requires login; lists the current user's saved trips)

## GitHub submission
Upload the project folder contents to a new GitHub repository. Include `config/config.example.php`, but **never commit `config/config.php`, real database passwords, or private credentials**. This project intentionally does not include a live hosting database or real booking/payment integrations.

## Important limitations
- Itinerary generation is a local suggestion based on the selected sample places; it does not calculate real routes or live travel times.
- Budget figures are entered by the user; live prices are not fetched.
- Rapido, Swiggy and hotel links open external services. This project does not process bookings or payments.
