"use strict";

// TOURIST PLACES FOR EACH DESTINATION
const cityPlaces = {
  "Mumbai": [
    "Gateway of India",
    "Marine Drive",
    "Elephanta Caves",
    "Juhu Beach",
    "Siddhivinayak Temple",
    "Chhatrapati Shivaji Maharaj Terminus",
    "Haji Ali Dargah",
    "Sanjay Gandhi National Park"
  ],
  "New Delhi": [
    "India Gate",
    "Red Fort",
    "Qutub Minar",
    "Humayun's Tomb",
    "Lotus Temple",
    "Akshardham Temple",
    "Jama Masjid",
    "Lodhi Garden"
  ],
  "Hyderabad": [
    "Charminar",
    "Golconda Fort",
    "Hussain Sagar",
    "Salar Jung Museum",
    "Chowmahalla Palace",
    "Birla Mandir",
    "Nehru Zoological Park",
    "Shilparamam"
  ],
  "Bengaluru": [
    "Lalbagh Botanical Garden",
    "Cubbon Park",
    "Bengaluru Palace",
    "Vidhana Soudha",
    "Bannerghatta Biological Park",
    "ISKCON Temple",
    "Ulsoor Lake",
    "Commercial Street"
  ],
  "Agra": [
    "Taj Mahal",
    "Agra Fort",
    "Fatehpur Sikri",
    "Mehtab Bagh",
    "Itimad-ud-Daulah's Tomb",
    "Akbar's Tomb",
    "Jama Masjid",
    "Sikandra"
  ],
  "Jaipur": [
    "Hawa Mahal",
    "Amber Fort",
    "City Palace",
    "Jantar Mantar",
    "Jal Mahal",
    "Nahargarh Fort",
    "Albert Hall Museum",
    "Jaigarh Fort",
    "Birla Temple",
    "Galtaji Temple",
    "Patrika Gate"
  ],
  "Chennai": [
    "Marina Beach",
    "Kapaleeshwarar Temple",
    "Fort St George",
    "Government Museum",
    "San Thome Basilica",
    "Elliot's Beach",
    "Guindy National Park",
    "Valluvar Kottam"
  ],
  "Kolkata": [
    "Victoria Memorial",
    "Howrah Bridge",
    "Dakshineswar Kali Temple",
    "Indian Museum",
    "Marble Palace",
    "Prinsep Ghat",
    "St. Paul's Cathedral",
    "Science City"
  ],
  "Varanasi": [
    "Kashi Vishwanath Temple",
    "Dashashwamedh Ghat",
    "Assi Ghat",
    "Sarnath",
    "Manikarnika Ghat",
    "Ramnagar Fort",
    "Bharat Mata Temple",
    "Tulsi Manas Temple"
  ],
  "Panaji": [
    "Fontainhas Latin Quarter",
    "Miramar Beach",
    "Dona Paula Viewpoint",
    "Our Lady of the Immaculate Conception Church",
    "Reis Magos Fort",
    "Goa State Museum",
    "Campal Gardens",
    "Mandovi Riverfront"
  ],
  "Pune": [
    "Shaniwar Wada",
    "Aga Khan Palace",
    "Sinhagad Fort",
    "Dagdusheth Halwai Ganpati Temple",
    "Raja Dinkar Kelkar Museum",
    "Parvati Hill",
    "Pataleshwar Cave Temple",
    "Khadakwasla Dam"
  ],
  "Ahmedabad": [
    "Sabarmati Ashram",
    "Adalaj Stepwell",
    "Kankaria Lake",
    "Sidi Saiyyed Mosque",
    "Jama Masjid",
    "Bhadra Fort",
    "Sabarmati Riverfront",
    "Science City"
  ],
  "Visakhapatnam": [
    "RK Beach",
    "Kailasagiri",
    "Submarine Museum",
    "Borra Caves",
    "Araku Valley",
    "Yarada Beach",
    "Simhachalam Temple",
    "Dolphin's Nose"
  ],
  "Vijayawada": [
    "Kanaka Durga Temple",
    "Prakasam Barrage",
    "Undavalli Caves",
    "Bhavani Island",
    "Kondapalli Fort",
    "Gandhi Hill",
    "Bapu Museum",
    "Mangalagiri Temple"
  ],
  "Kochi": [
    "Fort Kochi",
    "Chinese Fishing Nets",
    "Mattancherry Palace",
    "Paradesi Synagogue",
    "Marine Drive",
    "Hill Palace Museum",
    "Cherai Beach",
    "Kerala Folklore Museum"
  ],
  "Mysuru": [
    "Mysore Palace",
    "Chamundi Hill",
    "Brindavan Gardens",
    "St. Philomena's Church",
    "Mysuru Zoo",
    "Jaganmohan Palace",
    "Karanji Lake",
    "Devaraja Market"
  ],
  "Lucknow": [
    "Bara Imambara",
    "Chota Imambara",
    "Rumi Darwaza",
    "British Residency",
    "Hazratganj",
    "Ambedkar Memorial Park",
    "La Martiniere College",
    "Janeshwar Mishra Park"
  ],
  "Amritsar": [
    "Golden Temple",
    "Jallianwala Bagh",
    "Wagah Border",
    "Durgiana Temple",
    "Partition Museum",
    "Gobindgarh Fort",
    "Ram Bagh Palace",
    "Hall Bazaar"
  ],
  "Srinagar": [
    "Dal Lake",
    "Mughal Gardens",
    "Shankaracharya Temple",
    "Hazratbal Shrine",
    "Pari Mahal",
    "Nishat Bagh",
    "Shalimar Bagh",
    "Indira Gandhi Memorial Tulip Garden"
  ],
  "Chandigarh": [
    "Rock Garden",
    "Sukhna Lake",
    "Zakir Hussain Rose Garden",
    "Capitol Complex",
    "Government Museum and Art Gallery",
    "Japanese Garden",
    "Sector 17 Plaza",
    "Terraced Garden"
  ],
  "Udaipur": [
    "City Palace",
    "Lake Pichola",
    "Fateh Sagar Lake",
    "Saheliyon Ki Bari",
    "Jagdish Temple",
    "Sajjangarh Monsoon Palace",
    "Bagore Ki Haveli",
    "Jag Mandir",
    "Moti Magri",
    "Gulab Bagh",
    "Shilpgram",
    "Ambrai Ghat"
  ],
  "Jodhpur": [
    "Mehrangarh Fort",
    "Umaid Bhawan Palace",
    "Jaswant Thada",
    "Clock Tower and Sardar Market",
    "Mandore Gardens",
    "Toorji Ka Jhalra",
    "Rao Jodha Desert Rock Park",
    "Kaylana Lake"
  ],
  "Indore": [
    "Rajwada Palace",
    "Lal Bagh Palace",
    "Kanch Mandir",
    "Sarafa Bazaar",
    "Chappan Dukan",
    "Annapurna Temple",
    "Pipliyapala Regional Park",
    "Ralamandal Wildlife Sanctuary"
  ],
  "Bhopal": [
    "Upper Lake",
    "Van Vihar National Park",
    "Taj-ul-Masajid",
    "Bhimbetka Rock Shelters",
    "Sanchi Stupa",
    "State Museum Bhopal",
    "Gohar Mahal",
    "Tribal Museum"
  ],
  "Surat": [
    "Dumas Beach",
    "Dutch Garden",
    "Sardar Patel Museum",
    "Surat Castle",
    "Gopi Talav",
    "Science Centre Surat",
    "Sarthana Nature Park",
    "Ambika Niketan Temple"
  ],
  "Patna": [
    "Golghar",
    "Bihar Museum",
    "Patna Museum",
    "Takht Sri Patna Sahib",
    "Kumhrar",
    "Sanjay Gandhi Biological Park",
    "Buddha Smriti Park",
    "Agam Kuan"
  ],
  "Bhubaneswar": [
    "Lingaraj Temple",
    "Udayagiri and Khandagiri Caves",
    "Mukteshwar Temple",
    "Rajarani Temple",
    "Dhauli Shanti Stupa",
    "Nandankanan Zoological Park",
    "Odisha State Museum",
    "Ekamra Kanan"
  ],
  "Guwahati": [
    "Kamakhya Temple",
    "Umananda Temple",
    "Assam State Museum",
    "Srimanta Sankardev Kalakshetra",
    "Pobitora Wildlife Sanctuary",
    "Brahmaputra Riverfront",
    "Basistha Ashram",
    "Deepor Beel"
  ],
  "Thiruvananthapuram": [
    "Kovalam Beach",
    "Padmanabhaswamy Temple",
    "Napier Museum",
    "Kuthiramalika Palace",
    "Shanghumukham Beach",
    "Poovar Island",
    "Kanakakunnu Palace",
    "Veli Tourist Village"
  ],
  "Coimbatore": [
    "Marudhamalai Temple",
    "Perur Pateeswarar Temple",
    "VOC Park and Zoo",
    "Gass Forest Museum",
    "Isha Yoga Center",
    "Siruvani Waterfalls",
    "Gedee Car Museum",
    "Eachanari Vinayagar Temple"
  ],
  "Madurai": [
    "Meenakshi Amman Temple",
    "Thirumalai Nayakkar Palace",
    "Gandhi Memorial Museum",
    "Alagar Kovil",
    "Vandiyur Mariamman Teppakulam",
    "Thiruparankundram Murugan Temple",
    "Koodal Azhagar Temple",
    "Pazhamudircholai"
  ],
  "Tirupati": [
    "Sri Venkateswara Temple",
    "Sri Govindaraja Swamy Temple",
    "Kapila Theertham",
    "Sri Padmavathi Ammavari Temple",
    "Chandragiri Fort",
    "Talakona Waterfalls",
    "Silathoranam",
    "Sri Venkateswara Zoological Park"
  ],
  "Rishikesh": [
    "Lakshman Jhula area",
    "Ram Jhula",
    "Triveni Ghat",
    "Parmarth Niketan",
    "Neer Garh Waterfall",
    "Beatles Ashram",
    "Bharat Mandir",
    "Shivpuri rafting area"
  ],
  "Haridwar": [
    "Har Ki Pauri",
    "Mansa Devi Temple",
    "Chandi Devi Temple",
    "Maya Devi Temple",
    "Bharat Mata Mandir",
    "Shantikunj",
    "Daksha Mahadev Temple",
    "Rajaji National Park"
  ],
  "Shimla": [
    "The Ridge",
    "Mall Road",
    "Jakhoo Temple",
    "Christ Church",
    "Kufri",
    "Viceregal Lodge",
    "Annandale",
    "Green Valley"
  ],
  "Manali": [
    "Hadimba Devi Temple",
    "Solang Valley",
    "Old Manali",
    "Vashisht Hot Springs",
    "Manu Temple",
    "Jogini Waterfall",
    "Naggar Castle",
    "Rohtang Pass (seasonal access)"
  ],
  "Dehradun": [
    "Robber's Cave",
    "Sahastradhara",
    "Forest Research Institute",
    "Tapkeshwar Temple",
    "Mindrolling Monastery",
    "Malsi Deer Park",
    "Lachhiwala Nature Park",
    "Paltan Bazaar"
  ],
  "Darjeeling": [
    "Tiger Hill",
    "Batasia Loop",
    "Darjeeling Himalayan Railway",
    "Peace Pagoda",
    "Padmaja Naidu Himalayan Zoological Park",
    "Himalayan Mountaineering Institute",
    "Happy Valley Tea Estate",
    "Rock Garden"
  ],
  "Ooty": [
    "Ooty Lake",
    "Government Botanical Garden",
    "Doddabetta Peak",
    "Rose Garden",
    "Nilgiri Mountain Railway",
    "Pykara Falls",
    "Tea Factory and Museum",
    "Avalanche Lake"
  ],
  "Mangaluru": [
    "Panambur Beach",
    "Tannirbhavi Beach",
    "Kadri Manjunath Temple",
    "Kudroli Gokarnath Temple",
    "St. Aloysius Chapel",
    "Sultan Battery",
    "Pilikula Nisರ್ಗadhama",
    "Someshwara Beach"
  ],
  "Nashik": [
    "Trimbakeshwar Temple",
    "Pandav Leni Caves",
    "Sula Vineyards",
    "Ramkund",
    "Kalaram Temple",
    "Anjaneri Hills",
    "Coin Museum",
    "Gangapur Dam"
  ],
  "Rajkot": [
    "Kaba Gandhi No Delo",
    "Watson Museum",
    "Rotary Dolls Museum",
    "Race Course Ground",
    "Aji Dam",
    "Ishwariya Park",
    "Swaminarayan Temple",
    "Pradyuman Park"
  ],
  "Nagpur": [
    "Deekshabhoomi",
    "Futala Lake",
    "Maharajbagh Zoo",
    "Sitabuldi Fort",
    "Dragon Palace Temple",
    "Ambazari Lake",
    "Raman Science Centre",
    "Zero Mile Stone"
  ],
  "Jaisalmer": [
    "Jaisalmer Fort",
    "Patwon Ki Haveli",
    "Gadisar Lake",
    "Sam Sand Dunes",
    "Nathmal Ki Haveli",
    "Salim Singh Ki Haveli",
    "Bada Bagh",
    "Kuldhara Village"
  ],
  "Ajmer": [
    "Ajmer Sharif Dargah",
    "Ana Sagar Lake",
    "Adhai Din Ka Jhonpra",
    "Taragarh Fort",
    "Akbari Fort and Museum",
    "Nasiyan Jain Temple",
    "Foy Sagar Lake",
    "Pushkar Lake (nearby)"
  ],
  "Gwalior": [
    "Gwalior Fort",
    "Jai Vilas Palace",
    "Sas Bahu Temples",
    "Teli Ka Mandir",
    "Gujari Mahal Archaeological Museum",
    "Tansen Tomb",
    "Sun Temple",
    "Gopachal Jain Rock Cut Sculptures"
  ],
  "Meerut": [
    "Augarnath Temple",
    "Gandhi Bagh",
    "Hastinapur (nearby)",
    "Shahpeer's Mausoleum",
    "St. John's Church",
    "Suraj Kund",
    "Vidyut Nagar Park",
    "Martyr's Memorial"
  ],
  "Noida": [
    "Okhla Bird Sanctuary",
    "Botanic Garden of Indian Republic",
    "Worlds of Wonder",
    "DLF Mall of India",
    "The Grand Venice Mall",
    "ISKCON Noida",
    "Noida Stadium",
    "Rashtriya Dalit Prerna Sthal"
  ],
  "Gurugram": [
    "Kingdom of Dreams area",
    "Sultanpur National Park",
    "Sheetla Mata Mandir",
    "Leisure Valley Park",
    "Aravalli Biodiversity Park",
    "Cyber Hub",
    "Museo Camera",
    "Damdama Lake"
  ],
  "Tiruchirappalli": [
    "Sri Ranganathaswamy Temple",
    "Rockfort Ucchi Pillayar Temple",
    "Jambukeswarar Temple",
    "Kallanai Dam",
    "St. Joseph's Church",
    "Government Museum",
    "Mukkombu",
    "Our Lady of Lourdes Church"
  ]
};

const times = [
  "9:00 AM",
  "11:00 AM",
  "1:00 PM",
  "3:00 PM",
  "5:00 PM",
  "7:00 PM"
];

const suggestions = {
  culture: "Explore local history, landmarks and culture.",
  nature: "Enjoy the outdoors and nearby scenery.",
  relax: "Take your time and enjoy a relaxed visit.",
  food: "Explore local food and nearby restaurants."
};

const citySelect = document.getElementById("city");
const placesContainer = document.getElementById("places");
const tripForm = document.getElementById("tripForm");
const output = document.getElementById("output");
const emptyMessage = document.getElementById("empty");
const errorMessage = document.getElementById("error");

// SAFELY FORMAT TEXT
function escapeText(value) {
  return String(value).replace(/[&<>"']/g, function (character) {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };

    return entities[character];
  });
}

// DISPLAY PLACES BASED ON DESTINATION
function showPlaces() {
  const city = citySelect.value;
  const places = cityPlaces[city] || [];

  placesContainer.replaceChildren();

  places.forEach(function (place, index) {
    const label = document.createElement("label");
    label.className = "place";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "place";
    checkbox.value = place;
    checkbox.id = "place" + index;

    const text = document.createElement("span");
    text.textContent = place;

    label.append(checkbox, text);
    placesContainer.appendChild(label);
  });
}

// UPDATE THE PLACE LIST WHEN THE CITY CHANGES
citySelect.addEventListener("change", function () {
  showPlaces();
  output.innerHTML = "";
  emptyMessage.classList.remove("hidden");
  errorMessage.textContent = "";
});

showPlaces();

// AUTHENTICATION: PHP session-backed login and registration
async function authRequest(action) {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const message = document.getElementById("authMessage");
  message.textContent = "";
  try {
    const response = await fetch("api/auth.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, email, password })
    });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.message || "Authentication failed.");
    document.getElementById("userEmail").textContent = data.user.email;
    document.getElementById("login").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
  } catch (error) {
    message.textContent = error.message;
  }
}

document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();
  authRequest("login");
});
document.getElementById("registerBtn").addEventListener("click", function() {
  authRequest("register");
});

document.getElementById("logout").addEventListener("click", async function() {
  try {
    await fetch("api/auth.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "logout" })
    });
  } finally {
    document.getElementById("app").classList.add("hidden");
    document.getElementById("login").classList.remove("hidden");
    document.getElementById("email").value = "";
    document.getElementById("password").value = "";
    tripForm.reset();
    citySelect.value = "Hyderabad";
    showPlaces();
    output.innerHTML = "";
    emptyMessage.classList.remove("hidden");
    errorMessage.textContent = "";
  }
});

// Restore an existing PHP session after refreshing the page.
(async function restoreSession() {
  try {
    const response = await fetch("api/auth.php?action=me");
    const data = await response.json();
    if (data.success && data.user) {
      document.getElementById("userEmail").textContent = data.user.email;
      document.getElementById("login").classList.add("hidden");
      document.getElementById("app").classList.remove("hidden");
    }
  } catch (_) {}
})();

// GENERATE THE TRIP ITINERARY
tripForm.addEventListener("submit", function (event) {
  event.preventDefault();
  errorMessage.textContent = "";

  const city = citySelect.value;
  const days = Number(document.getElementById("days").value);
  const budget = Number(document.getElementById("budget").value);
  const people = Number(document.getElementById("people").value);
  const style = document.getElementById("style").value;

  const selected = Array.from(
    document.querySelectorAll('input[name="place"]:checked')
  ).map(function (item) {
    return item.value;
  });

  if (selected.length === 0) {
    errorMessage.textContent = "Please select at least one place.";
    return;
  }

  if (!Number.isInteger(days) || days < 1) {
    errorMessage.textContent = "Please select a valid number of days.";
    return;
  }

  if (!Number.isFinite(budget) || budget <= 0) {
    errorMessage.textContent = "Enter a valid budget greater than zero.";
    return;
  }

  if (!Number.isInteger(people) || people < 1) {
    errorMessage.textContent = "Enter a valid whole number of travelers.";
    return;
  }

  // BUDGET SUMMARY
  let html = `
    <h2>${escapeText(city)} Trip</h2>

    <p class="muted">
      ${days} day(s) · ${people} traveler(s) ·
      ${selected.length} selected place(s)
    </p>

    <div class="stats">
      <div class="stat">
        <small>Total Budget</small>
        <strong>₹${budget.toLocaleString("en-IN", {
          maximumFractionDigits: 2
        })}</strong>
      </div>

      <div class="stat">
        <small>Daily Budget</small>
        <strong>₹${(budget / days).toLocaleString("en-IN", {
          maximumFractionDigits: 2
        })}</strong>
      </div>

      <div class="stat">
        <small>Budget Per Person</small>
        <strong>₹${(budget / people).toLocaleString("en-IN", {
          maximumFractionDigits: 2
        })}</strong>
      </div>
    </div>

    <p class="muted">
      Suggested itinerary. Check opening hours, entry fees and
      travel times before visiting.
    </p>
  `;

  // DISTRIBUTE PLACES ACROSS THE DAYS
  let index = 0;

  for (let day = 1; day <= days; day++) {
    const remainingPlaces = selected.length - index;
    const remainingDays = days - day + 1;
    const placesToday = Math.ceil(remainingPlaces / remainingDays);

    html += `<div class="day"><h3>Day ${day}</h3>`;

    if (placesToday === 0) {
      html += '<p class="muted">Free time, meals or rest.</p>';
    }

    for (let count = 0; count < placesToday; count++) {
      html += `
        <div class="stop">
          <strong>${times[count % times.length]}</strong><br>
          ${escapeText(selected[index])}
          <p class="muted">${escapeText(suggestions[style])}</p>
        </div>
      `;

      index++;
    }

    html += "</div>";
  }

  // MAP AND PRINT BUTTONS
  const mapQuery = encodeURIComponent(city + " tourist attractions");

  html += `
    <div class="actions">
      <a class="btn"
         href="https://www.google.com/maps/search/?api=1&query=${mapQuery}"
         target="_blank"
         rel="noopener">
        Explore on Google Maps ↗
      </a>

      <button type="button" id="printBtn">
        Print / Save PDF
      </button>
    </div>

    <p class="muted">
      This demo uses sample place lists and a suggested schedule.
      It does not calculate actual routes, live prices or bookings.
    </p>
  `;

  output.innerHTML = html;
  emptyMessage.classList.add("hidden");

  // Save this trip to the logged-in user's MySQL account.
  fetch("api/trips.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      destination: city, days, budget, travelers: people,
      preference: style, places: selected
    })
  }).then(async response => {
    const data = await response.json();
    if (!response.ok || !data.success) {
      console.warn("Trip was generated but not saved:", data.message || "Save failed");
    }
  }).catch(error => console.warn("Trip save unavailable:", error));

  document.getElementById("printBtn").addEventListener("click", function () {
    window.print();
  });
});