<?php
// Copy this file to config.php and update your local MySQL credentials.
// Do not upload config.php containing real credentials to GitHub.
define('DB_HOST', 'localhost');
define('DB_NAME', 'tripmate');
define('DB_USER', 'root');
define('DB_PASS', '');
