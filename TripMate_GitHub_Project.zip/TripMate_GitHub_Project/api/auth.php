<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'me') {
    if (!empty($_SESSION['user_id'])) {
        json_response(['success' => true, 'user' => ['id' => $_SESSION['user_id'], 'email' => $_SESSION['user_email']]]);
    }
    json_response(['success' => false, 'user' => null], 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['success' => false, 'message' => 'Method not allowed.'], 405);
$data = json_input();
$action = $data['action'] ?? '';

if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    json_response(['success' => true, 'message' => 'Logged out.']);
}

$email = filter_var(trim((string)($data['email'] ?? '')), FILTER_VALIDATE_EMAIL);
$password = (string)($data['password'] ?? '');
if (!$email || strlen($password) < 8) json_response(['success' => false, 'message' => 'Enter a valid email and a password of at least 8 characters.'], 422);

try {
    if ($action === 'register') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)');
        try { $stmt->execute([$email, $hash]); }
        catch (PDOException $e) {
            if ($e->getCode() === '23000') json_response(['success' => false, 'message' => 'This email is already registered. Please log in.'], 409);
            throw $e;
        }
        $id = (int)db()->lastInsertId();
    } elseif ($action === 'login') {
        $stmt = db()->prepare('SELECT id, email, password_hash FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password_hash'])) {
            json_response(['success' => false, 'message' => 'Incorrect email or password.'], 401);
        }
        $id = (int)$user['id'];
    } else {
        json_response(['success' => false, 'message' => 'Unknown action.'], 400);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    $_SESSION['user_email'] = $email;
    json_response(['success' => true, 'user' => ['id' => $id, 'email' => $email]]);
} catch (Throwable $e) {
    error_log($e->getMessage());
    json_response(['success' => false, 'message' => 'Server error. Check database setup and PHP error logs.'], 500);
}
