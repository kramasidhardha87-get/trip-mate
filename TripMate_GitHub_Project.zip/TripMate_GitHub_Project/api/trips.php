<?php
declare(strict_types=1);
session_start();
require_once __DIR__ . '/../db.php';

$userId = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = db()->prepare('SELECT id, destination, days, budget, travelers, preference, places_json, created_at FROM trips WHERE user_id = ? ORDER BY created_at DESC');
    $stmt->execute([$userId]);
    json_response(['success' => true, 'trips' => $stmt->fetchAll()]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['success' => false, 'message' => 'Method not allowed.'], 405);
$data = json_input();
$destination = trim((string)($data['destination'] ?? ''));
$days = filter_var($data['days'] ?? null, FILTER_VALIDATE_INT);
$budget = filter_var($data['budget'] ?? null, FILTER_VALIDATE_FLOAT);
$travelers = filter_var($data['travelers'] ?? null, FILTER_VALIDATE_INT);
$preference = trim((string)($data['preference'] ?? ''));
$places = $data['places'] ?? [];

if ($destination === '' || !$days || $days < 1 || !$budget || $budget <= 0 || !$travelers || $travelers < 1 || !is_array($places) || count($places) < 1) {
    json_response(['success' => false, 'message' => 'Invalid trip details.'], 422);
}
$allowed = ['culture', 'nature', 'relax', 'food'];
if (!in_array($preference, $allowed, true)) $preference = 'culture';

$stmt = db()->prepare('INSERT INTO trips (user_id, destination, days, budget, travelers, preference, places_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
$stmt->execute([$userId, $destination, $days, $budget, $travelers, $preference, json_encode(array_values($places), JSON_UNESCAPED_UNICODE)]);
json_response(['success' => true, 'trip_id' => (int)db()->lastInsertId(), 'message' => 'Trip saved.'], 201);
