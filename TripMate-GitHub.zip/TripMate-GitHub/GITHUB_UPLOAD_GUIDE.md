# Upload TripMate to GitHub (without using a terminal)

## 1. Extract the project

Extract `TripMate-GitHub.zip` on your computer. Open the extracted `TripMate-GitHub` folder and confirm that it contains `index.html`, `README.md`, `.gitignore`, `LICENSE`, and this guide.

## 2. Create a repository

1. Sign in at https://github.com/.
2. Click **+ → New repository**.
3. Repository name: `tripmate-travel-planner` (or another name you prefer).
4. Add a short description such as `A responsive travel-planning prototype built with HTML, CSS, and JavaScript`.
5. Choose **Public** if you want everyone to see it, or **Private** for restricted access.
6. Since this project already contains a README, leave the options to add a README, `.gitignore`, or license unchecked to avoid creating duplicates.
7. Click **Create repository**.

## 3. Upload the project files

1. In the new empty repository, choose **Add file → Upload files**.
2. Open the extracted project folder on your computer.
3. Select all five project files, including the hidden `.gitignore` file if your file picker shows it. You can upload `index.html`, `README.md`, `GITHUB_UPLOAD_GUIDE.md`, `.gitignore`, and `LICENSE` together.
4. Drag them into GitHub's upload area.
5. Add a commit message such as `Add TripMate travel planner prototype`.
6. Click **Commit changes**.

Make sure `index.html` is at the repository root—not inside an extra nested folder.

## 4. Publish the live website (optional)

1. Open **Settings → Pages** in the repository.
2. Under **Build and deployment**, set the source to **Deploy from a branch**.
3. Select branch `main` and folder `/(root)`, then save.
4. Return to the Pages section to find the published website URL.

## 5. Test it

Open `index.html` from the published URL. Try the demo email login, change the destination, select at least one attraction, generate the itinerary, and test the map and print buttons.

## Before sharing publicly

- Do not add passwords, API keys, private information, or real user credentials.
- Clearly describe this as a prototype in the repository description and README.
- Test the published URL after deployment.
