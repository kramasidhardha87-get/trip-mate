# TripMate – Smart Travel Planner ✈️

TripMate is a responsive, browser-based travel-planning prototype. It helps users select an Indian destination, choose tourist places, create a suggested day-wise itinerary, and review a simple budget summary.

## Features

- Demo email login and logout
- Destination selector with sample tourist attractions across Indian cities
- Place selection using checkboxes
- Trip duration, traveller count, budget, and travel-preference inputs
- Automatically distributes selected places across the chosen days
- Total budget, daily budget, and budget-per-person calculations
- Links to Google Maps, Rapido, Swiggy, and hotel search on MakeMyTrip
- Print the itinerary or use the browser's **Save as PDF** option
- Responsive layout for desktop and smaller screens

## Technologies

- HTML5
- CSS3 (Grid, responsive media queries, and print styles)
- Vanilla JavaScript (DOM manipulation, event handling, form validation)

No package installation or build step is required.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Enter an email address to try the demo login, choose a destination and places, then select **Generate My Trip**.

You can also use the **Live Server** extension in Visual Studio Code, but it is not required.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the files in this project folder.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose the `main` branch and the `/(root)` folder, then save.
5. Wait for GitHub Pages to publish the site; the Pages screen will show the published URL.

Keep `index.html` in the repository root so GitHub Pages can find the home page.

## Important prototype limitations

- Login is a front-end demo only. It does not create accounts, verify email addresses, or securely authenticate users.
- Destination attractions are sample data stored in the JavaScript file.
- The itinerary is a suggested distribution of selected attractions, not a route-optimisation system.
- Budget values are basic arithmetic estimates entered by the user; the app does not fetch live prices, transport routes, opening hours, or ticket fees.
- External service links open third-party websites. This prototype does not process bookings or payments.
- There is currently no server, database, or external API integration.

These limitations are intentional for this front-end prototype and should be addressed before describing the project as a full production travel service.

## Project structure

```text
TripMate-GitHub/
├── index.html                 # Main page, styles, and JavaScript
├── README.md                  # Project overview and run/deployment instructions
├── GITHUB_UPLOAD_GUIDE.md     # Step-by-step GitHub upload guide
├── .gitignore                 # Common local/editor files to exclude
└── LICENSE                    # MIT License
```

## License

This project is provided under the MIT License. See [LICENSE](LICENSE).
